﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FireSharp;
using FireSharp.Config;
using FireSharp.Interfaces;
using FireSharp.Response;
using WebClient;

namespace WebClient
{
    class ConfigFirebase
    {
       
        static IFirebaseConfig config = new FirebaseConfig { BasePath = "https://doanchuyennganha-f2d83-default-rtdb.firebaseio.com/" };

        static FirebaseClient client = new FirebaseClient(config);

        //public async void ListenFireBase(DataGridView gridUserList)
        //{
        //    EventStreamResponse response = await client.OnAsync("users",
        //        added: (sender, args, context) => { UpdateDataGridView(gridUserList); },
        //            changed: (sender, args, context) => { UpdateDataGridView(gridUserList); },
        //                removed: (sender, args, context) => { UpdateDataGridView(gridUserList); });

        //}

        //public async void ListenFireBaseHistory(DataGridView gridHistoryIOT)
        //{
        //    EventStreamResponse response = await client.OnAsync("HistoryIOT",
        //        added: (sender, args, context) => { UpdateDataGridViewToHistory(gridHistoryIOT); },
        //            changed: (sender, args, context) => { UpdateDataGridViewToHistory(gridHistoryIOT); },
        //                removed: (sender, args, context) => { UpdateDataGridViewToHistory(gridHistoryIOT); });
        //}

        //public async void ListenFireBaseIOT(DataGridView gridCommands)
        //{
        //    EventStreamResponse response = await client.OnAsync("Commands",
        //        added: (sender, args, context) => { UpdateDataGridViewToCommands(gridCommands); },
        //            changed: (sender, args, context) => { UpdateDataGridViewToCommands(gridCommands); },
        //                removed: (sender, args, context) => { UpdateDataGridViewToCommands(gridCommands); });
        //}

        //public async void ListenFireBaseIOTNormalUserController(DataGridView gridCommands, string location)
        //{
        //    EventStreamResponse response = await client.OnAsync("Commands",
        //        added: (sender, args, context) => { UpdateDataGridViewToCommandsControl(gridCommands, location); },
        //            changed: (sender, args, context) => { UpdateDataGridViewToCommandsControl(gridCommands, location); },
        //                removed: (sender, args, context) => { UpdateDataGridViewToCommandsControl(gridCommands, location); });
        //}

        //public async void ListenFireBaseIOTConnection(DataGridView gridConnectionIOT)
        //{
        //    EventStreamResponse response = await client.OnAsync("StatusIOT",
        //        added: (sender, args, context) => { UpdateDataGridViewToConnection(gridConnectionIOT); },
        //            changed: (sender, args, context) => { UpdateDataGridViewToConnection(gridConnectionIOT); },
        //                removed: (sender, args, context) => { UpdateDataGridViewToConnection(gridConnectionIOT); });
        //}

        //private void UpdateDataGridView(DataGridView gridUserList)
        //{
        //    List<User> listuser = GetAll();
        //    gridUserList.BeginInvoke(new MethodInvoker(delegate { gridUserList.DataSource = listuser; gridUserList.Columns["Avatar"].Visible = false; }));
        //}
        //private void UpdateDataGridViewToHistory(DataGridView gridHistoryIOT)
        //{
        //    List<HistoryControlIOT> listhist = GetAllHistory();
        //    gridHistoryIOT.BeginInvoke(new MethodInvoker(delegate { gridHistoryIOT.DataSource = listhist; }));
        //}
        //private void UpdateDataGridViewToCommands(DataGridView gridCommands)
        //{
        //    List<Commands> listcmd = GetAllCommands();
        //    gridCommands.BeginInvoke(new MethodInvoker(delegate { gridCommands.DataSource = listcmd; }));
        //}

        //private void UpdateDataGridViewToCommandsControl(DataGridView gridCommands, string location)
        //{
        //    List<Commands> listcmd = GetControls(location);
        //    gridCommands.BeginInvoke(new MethodInvoker(delegate { gridCommands.DataSource = listcmd; }));
        //}

        //private void UpdateDataGridViewToConnection(DataGridView gridConnectionIOT)
        //{
        //    List<StatusConnection> liststatus = GetAllConnection();
        //    gridConnectionIOT.BeginInvoke(new MethodInvoker(delegate { gridConnectionIOT.DataSource = liststatus; }));
        //}


        //public List<StatusConnection> GetAllConnection()
        //{
        //    FirebaseResponse response = client.Get("StatusIOT");
        //    Dictionary<string, StatusConnection> dictcon = response.ResultAs<Dictionary<string, StatusConnection>>();
        //    return dictcon.Values.ToList();
        //}

        public List<Commands> GetAllCommands()
        {
            FirebaseResponse response = client.Get("Commands");
            Dictionary<string, Commands> dictcmds = response.ResultAs<Dictionary<string, Commands>>();
            return dictcmds.Values.ToList();
        }
        public List<User> GetAll()
        {
            FirebaseResponse response = client.Get("users");
            Dictionary<string, User> dictusers = response.ResultAs<Dictionary<string, User>>();
            return dictusers.Values.ToList();
        }
        public string GetKeyByUserName(string username)
        {
            FirebaseResponse response = client.Get("users");
            Dictionary<string, User> dictHumaninfos = response.ResultAs<Dictionary<string, User>>();
            string key = dictHumaninfos.FirstOrDefault(x => x.Value.UserName == username).Key;
            return key;
        }

        public string GetKeyByCode(int code)
        {
            FirebaseResponse response = client.Get("users");
            Dictionary<string, User> dictHumaninfos = response.ResultAs<Dictionary<string, User>>();
            string key = dictHumaninfos.FirstOrDefault(x => x.Value.Code == code).Key;
            return key;
        }




        public bool AddNew(User newuser)
        {
            foreach (var item in GetAll())
            {
                if (item.UserName == newuser.UserName || item.Code == newuser.Code)
                    return false;
            }
            try
            {
                
                newuser.Code = GetCodeToAddNewUser();
                client.Push("users", newuser);
                return true;
            }
            catch { return false; }
        }

        public User GetDetailsToLogin(string username)
        {
            FirebaseResponse response = client.Get("users/" + GetKeyByUserName(username));
            User user = response.ResultAs<User>();
            return user;
        }

        public User GetDetailsToGrid(int code)
        {
            FirebaseResponse response = client.Get("users/" + GetKeyByCode(code));
            User user = response.ResultAs<User>();
            return user;
        }


        public Commands GetDetailsToGridCmds(string location)
        {
            FirebaseResponse response = client.Get("Commands/" + location);
            Commands cmd = response.ResultAs<Commands>();
            return cmd;
        }

        public bool CheckLogin(string username, string password)
        {
            foreach (var item in GetAll())
            {
                if (item.UserName == username && item.Password == password)
                {
                    return true;
                }
            }
            return false;
        }

        //public bool Update(User user)
        //{
        //    try
        //    {
        //        string key = GetKeyByCode(user.Code);
        //        if (string.IsNullOrEmpty(key)) return false;
        //        client.Set("users/" + key, user);
        //        return true;
        //    }
        //    catch { return false; }
        //}


        //public void SaveHistory(HistoryControlIOT hist)
        //{
        //    try
        //    {
        //        client.Push("HistoryIOT", hist);
        //    }
        //    catch { }
        //}


        //public List<HistoryControlIOT> GetAllHistory()
        //{
        //    FirebaseResponse response = client.Get("HistoryIOT");
        //    Dictionary<string, HistoryControlIOT> dicthist = response.ResultAs<Dictionary<string, HistoryControlIOT>>();
        //    return dicthist.Values.ToList();
        //}
        public bool SetLamp(Commands cmd)
        {
            try
            {
                if (string.IsNullOrEmpty(cmd.location)) return false;
                client.Set("Commands/" + cmd.location, cmd);
                return true;
            }
            catch { return false; }
        }

        //public bool UpdateIOTStatus(Commands cmd)
        //{
        //    try
        //    {
        //        if (string.IsNullOrEmpty(cmd.location)) return false;
        //        client.Set("Commands/" + cmd.location, cmd);
        //        return true;
        //    }
        //    catch { return false; }
        //}


        //public bool Delete(int code)
        //{
        //    try
        //    {
        //        string key = GetKeyByCode(code);
        //        if (string.IsNullOrEmpty(key)) return false;
        //        client.Delete("users/" + key);
        //        return true;
        //    }
        //    catch { return false; }
        //}
        //public List<Commands> GetControls(string location)
        //{
        //    List<Commands> listcmd = new List<Commands>();
        //    foreach (var item in GetAllCommands())
        //    {
        //        if (item.location == location)
        //        {
        //            listcmd.Add(item);
        //        }
        //    }
        //    return listcmd;
        //}
        public List<User> Search(string keyword)
        {
            List<User> listhuman = new List<User>();
            foreach (var item in GetAll())
            {
                if (item.FullName.ToLower().Contains(keyword.ToLower()))
                {
                    listhuman.Add(item);
                }
            }
            return listhuman;
        }

        // Check Code Max After Add new User

        public int GetCodeToAddNewUser() 
        {
            int CodeMax = 0;
            foreach ( User user in GetAll())
            {
                if ( CodeMax < user.Code )
                {
                    CodeMax = user.Code;
                }
            }
            return CodeMax + 1;
        }
    }
}
