﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WebClient
{
    public class Commands
    {
        public string location { get; set; }
        public string gate { get; set; }

        public string lamp { get; set; }
    }
}
