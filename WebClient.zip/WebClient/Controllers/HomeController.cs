﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Web;
using System.Web.Mvc;


namespace WebClient.Controllers
{
    public class HomeController : Controller
    {
        
        public ActionResult Index()
        {
            if (Session["FullName"] != null)
            {
                return View();
            }
            else
            {
                return RedirectToAction("Login");
            }
            
        }

        public ActionResult Login()
        {
            return View();
        }

        [HttpPost]        
        public ActionResult Login(string username, string password)
        {
            if (ModelState.IsValid)
            {
                bool result = new ConfigFirebase().CheckLogin(username, new Md5Hash().GetMD5(password));               
                if (result)
                {
                    User currentuser = new ConfigFirebase().GetDetailsToLogin(username);
                    //add session
                    Session["FullName"] = currentuser.FullName;
                    Session["UserName"] = currentuser.UserName;
                    var Image = String.Format("data:image/gif;base64,{0}", currentuser.Avatar);
                    Session["User"] = currentuser as User;
                    Session["Avatar"] = Image;
                    List<Commands> listcmds = null ;                    
                    if (currentuser.locationController.Equals("All"))
                    {
                        listcmds = new ConfigFirebase().GetAllCommands();
                        Session["ListCommands"] = listcmds as List<Commands>;
                    }
                    else
                    {
                        Commands cmd = new ConfigFirebase().GetDetailsToGridCmds(currentuser.locationController);                        
                        Session["NomalCommands"] = cmd as Commands;
                    }

                   
                    return RedirectToAction("Index");
                }
                else
                {
                    ViewBag.error = "Login failed";
                    return RedirectToAction("Login");
                }
            }
            return View();
        }

        public ActionResult LogOut()
        {
            Session["FullName"] = null ;
            Session["ListCommands"] = null;
            Session["NomalCommands"] = null;
            Session["UserName"] = null;
            Session["User"] = null;
            Session["Avatar"] = null;
            return RedirectToAction("Login");
        }

        public ActionResult TurnGateOn()
        {
            return PartialView();
        }

        [HttpPost]
        public ActionResult SetDevice(Commands cmd)
        {
            
            bool result = new ConfigFirebase().SetLamp(cmd);
            if (result)
            {
                List<Commands> listcmds = null;
                if (Session["UserName"].Equals("admin"))
                {
                    listcmds = new ConfigFirebase().GetAllCommands();
                    Session["ListCommands"] = listcmds as List<Commands>;
                }
                else
                {
                    Commands newcmd = new ConfigFirebase().GetDetailsToGridCmds(cmd.location);
                    Session["NomalCommands"] = newcmd as Commands;
                }
                
                
            }
            return RedirectToAction("Index");

        }       
        

        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }

    }
}